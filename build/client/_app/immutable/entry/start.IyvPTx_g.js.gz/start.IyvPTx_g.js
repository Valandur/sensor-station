import{d as a}from"../chunks/entry.B8Kgx2WW.js";export{a as start};
