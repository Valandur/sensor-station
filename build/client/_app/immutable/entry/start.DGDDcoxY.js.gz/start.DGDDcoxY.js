import{d as a}from"../chunks/entry.CmczXKsn.js";export{a as start};
