import{d as a}from"../chunks/entry.DubRhAeh.js";export{a as start};
