import{d as a}from"../chunks/entry.FcHBK0nv.js";export{a as start};
