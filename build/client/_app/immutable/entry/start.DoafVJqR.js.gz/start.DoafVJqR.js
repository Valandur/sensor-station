import{e as a}from"../chunks/entry.DlEHMtX6.js";export{a as start};
