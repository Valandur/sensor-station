import{d as a}from"../chunks/entry.BWTpNdOx.js";export{a as start};
