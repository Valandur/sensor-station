import{d as a}from"../chunks/entry.Cc0r3sFu.js";export{a as start};
