import{d as a}from"../chunks/entry.DKjnRiPY.js";export{a as start};
