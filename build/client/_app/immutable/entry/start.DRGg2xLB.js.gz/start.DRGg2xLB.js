import{d as a}from"../chunks/entry.Dtfr9yDT.js";export{a as start};
