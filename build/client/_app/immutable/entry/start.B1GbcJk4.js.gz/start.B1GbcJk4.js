import{e as a}from"../chunks/entry.DU183Og8.js";export{a as start};
