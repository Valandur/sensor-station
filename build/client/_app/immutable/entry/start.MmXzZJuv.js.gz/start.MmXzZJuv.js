import{e as a}from"../chunks/entry.CF6BeJFX.js";export{a as start};
