import{d as a}from"../chunks/entry.DjNwTUz4.js";export{a as start};
