import{e as a}from"../chunks/entry.BqfWhJCV.js";export{a as start};
