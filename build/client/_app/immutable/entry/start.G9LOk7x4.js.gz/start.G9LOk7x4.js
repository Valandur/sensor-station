import{d as a}from"../chunks/entry.Mg4kpJ4P.js";export{a as start};
