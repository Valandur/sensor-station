import{e as a}from"../chunks/entry.CF0nH_QA.js";export{a as start};
