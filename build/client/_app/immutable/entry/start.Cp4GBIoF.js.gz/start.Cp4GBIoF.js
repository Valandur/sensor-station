import{d as a}from"../chunks/entry.Cia8U66t.js";export{a as start};
